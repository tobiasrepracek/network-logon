<?php
// Check if the required parameters are present in the GET request
if (isset($_GET['locip']) && isset($_GET['user']) && isset($_GET['pc'])) {
    // Get the parameters from the GET request
    $locip = $_GET['locip'];
    $user = $_GET['user'];
    $pc = $_GET['pc'];
    $t = date("h:i:s a",time());
    $dt = date("Y-m-d",time());
    
    // Prepare the log content
    $logContent = "Date: $dt\nTime: $t\nUser: $user\nIP: $locip\nPC: $pc\n\n";
    $logContent2 = "[$dt] ($t) $locip - $user - $pc\n";
    
    // Define the log file path
    $logFilePath = "/disky/logger/logs/$pc-$user.txt";
    $logFilePath2 = "/disky/logger/all.txt";
    
    // Open the log file in append mode or create it if it doesn't exist
    $fileHandle = fopen($logFilePath, 'a');
    $fileHandle2 = fopen($logFilePath2, 'a');
    
    // Write the log content to the file
    if ($fileHandle !== false) {
        if (fwrite($fileHandle, $logContent) !== false) {
            fclose($fileHandle);
            echo "Log appended successfully.";
            if (fwrite($fileHandle2, $logContent2) !== false) {
                fclose($fileHandle2);
                echo "Log appended successfully."; 
            }
        } else {
            echo "Failed to append log. Please check permissions and path.";
        }
    } else {
        echo "Failed to open log file.";
    }
} else {
    echo "<title>Missing parameters</title>Missing parameters.";
}
?>
